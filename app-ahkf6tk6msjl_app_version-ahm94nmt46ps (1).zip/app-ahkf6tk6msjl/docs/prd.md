# Requirements Document

## 1. Application Overview

- **Application Name:** Foot Rush
- **Description:** A modern, responsive e-commerce website for a shoe brand inspired by platforms like Amazon and Flipkart. The platform features a green-themed UI with dark/light mode toggle, gamified discount mechanics, advanced product filtering, wishlist management, order placement and tracking, reviews and ratings, trending and recently viewed sections, a rich product catalog, and a notifications system — designed to deliver a fast, visually appealing, and feature-rich shoe shopping experience.

---

## 2. Users & Use Cases

### Target Users
- General consumers looking to browse and purchase shoes online (men, women, kids)
- Sports and sneaker enthusiasts
- Hackathon judges evaluating UI/UX and feature innovation

### Core Use Cases
- Browse shoes by category, keyword search, and advanced filters
- View product details, add to cart, and complete checkout with full order placement flow
- Unlock discounts through gamified interactions
- Track orders and manage user profile
- Save favorite products to wishlist
- Read and submit product reviews and ratings
- Switch between dark and light mode
- Receive notifications for offers and order updates

---

## 3. Page Structure & Core Features

### 3.1 Page Overview

```
Foot Rush
├── Home Page
│   ├── Header / Navbar
│   ├── Category Section
│   ├── Hero Banner
│   ├── Trending Shoes Section
│   ├── Product Grid (with Advanced Filters)
│   ├── Flash Sale Section
│   ├── AI Recommendations Section
│   ├── Recently Viewed Section
│   └── Footer
├── Product Detail Page
├── Cart Page
├── Checkout Page
│   ├── Delivery Details Form
│   ├── Order Summary
│   └── Order Confirmation Screen
├── Wishlist Page
├── User Dashboard
│   ├── Profile Overview
│   ├── My Orders & Order Tracking
│   ├── Notifications
│   └── (Wishlist accessible via Wishlist Page)
├── Login / Signup Page
└── Crack the Code Game Page
```

---

### 3.2 Home Page

#### Header / Navbar
- Logo: Foot Rush (transparent background, left-aligned)
- Search bar with placeholder text: Search for shoes, brands…
- Location selector dropdown
- Login / Signup entry (redirects to Login/Signup Page)
- Cart icon with item count badge
- Wishlist icon (heart) with saved item count badge
- Notification bell icon with unread count badge; clicking opens a notification dropdown/panel
- Dark/Light mode toggle button (sun/moon icon); preference saved to local storage and applied on next visit
- Primary color: Green; secondary decorative elements include puzzle patterns and lock & key icons
- All navbar components adapt dynamically to the active theme (dark or light)

#### Category Section
- Horizontally scrollable category tabs: Men, Women, Kids, Sports, Sneakers, Casual, Formal
- Clicking a category filters the product grid below

#### Hero Banner
- Full-width animated slider with 2–3 banner slides
- Each slide highlights a promotional offer (e.g., Up to 50% OFF) and trending shoe imagery
- Auto-play with manual navigation arrows

#### Trending Shoes Section
- Section titled Trending Shoes
- Displays a horizontally scrollable row of popular or frequently viewed products
- Same product card structure as the product grid
- Positioned above the main product grid on the home page

#### Product Grid with Advanced Filters
- Filter panel (sidebar on desktop, collapsible drawer on mobile) with the following filters:
  - Price range slider (min–max)
  - Shoe size (multi-select chips)
  - Brand (multi-select checkboxes)
  - Color (color swatch multi-select)
- Filters dynamically update the product grid results in real time without page reload
- Active filters displayed as removable tags above the grid; a Clear All option resets all filters
- Grid layout (4 columns on desktop, 2 on mobile)
- Each product card displays:
  - Shoe image
  - Product name
  - Original price + discounted price + discount percentage badge
  - Star rating (e.g., 4.2 ⭐) with review count
  - Add to Cart button
  - Wishlist toggle (heart icon): adds/removes item from wishlist
- Clicking a card navigates to the Product Detail Page
- Product catalog includes a wide variety of shoe designs across categories: Sneakers, Sports, Casual, Formal — ensuring the homepage appears rich with products by default

#### Flash Sale Section
- Dedicated section with countdown timer
- Displays limited-time discounted products in a horizontal scroll row
- Same card structure as the product grid
- When the timer reaches zero, the flash sale section is hidden or replaced with a next sale teaser

#### AI Recommendations Section
- Section titled Suggested for You
- Displays a curated row of products (simulated recommendation logic based on category or viewed items)

#### Recently Viewed Section
- Tracks and displays the last 4–6 products the user has viewed in the current session
- For logged-in users, recently viewed history persists across sessions (stored in backend or local storage)
- Horizontally scrollable row

#### Footer
- Links: About Us, Contact, Careers
- Social media icons (Instagram, Facebook, Twitter/X, YouTube)
- Copyright notice
- Footer adapts to active theme

---

### 3.3 Product Detail Page
- Large product image gallery (main image + thumbnail row)
- Product name, brand, price, discount, and average star rating with total review count
- Size selector (available sizes displayed as clickable chips)
- Color selector (color swatches)
- Add to Cart and Add to Wishlist buttons
- Product description and key features
- **Reviews & Ratings Section:**
  - Display list of existing user reviews (star rating + written review + reviewer name + date)
  - Average rating displayed prominently (e.g., 4.2 / 5 based on N reviews)
  - Review submission form for logged-in users:
    - Star rating selector (1–5 stars)
    - Text area for written review
    - Submit button
  - Guests are prompted to log in to submit a review
- Related products section at the bottom

---

### 3.4 Cart Page
- List of added items with image, name, size, color, quantity selector, and price
- Remove item option per line
- Order summary panel: subtotal, discount applied, estimated total
- Coupon code input field (accepts codes from Crack the Code game)
- Proceed to Checkout button

---

### 3.5 Checkout Page

#### Delivery Details Form
- Fields: Full Name, Phone Number, Address (with optional location auto-fill support if browser geolocation is available), Pincode
- Inline validation for all required fields

#### Order Summary
- Read-only summary of items, quantities, prices, applied discount, and estimated total
- Displayed before the user confirms the order

#### Payment Method Selection
- Placeholder options: Card, UPI, Cash on Delivery
- Secure checkout visual: lock icon with subtle animation on confirm

#### Place Order Flow
- Place Order button submits the order
- On success: navigates to Order Confirmation Screen
  - Displays order ID, summary of items, delivery address, estimated delivery date
  - Option to continue shopping or view order in dashboard
- Network error on submission: display error toast and allow retry without data loss

---

### 3.6 Wishlist Page
- Dedicated page accessible from the navbar wishlist icon or user dashboard
- Grid of wishlisted products with image, name, price, and discount
- Move to Cart button per item
- Remove from Wishlist button per item
- Empty state message if no items are saved: Your wishlist is empty. Start adding your favorites!
- Available to both guests (session-based) and logged-in users (account-based); guest wishlist is not persisted after session ends

---

### 3.7 User Dashboard

#### Profile Overview
- Display name, email, profile avatar
- Edit profile option

#### My Orders & Order Tracking
- List of past and active orders with status badges (Processing, Shipped, Out for Delivery, Delivered, Returned)
- Order detail view with a visual timeline:
  - Ordered → Confirmed → Shipped → Out for Delivery → Delivered
- Timeline reflects current order status; statuses update in sequence and cannot go backwards
- If tracking status is unavailable: display message — Tracking information not yet available. Please check back later.

#### Notifications
- List of recent notifications: promotional offers, delivery status updates, order confirmations
- Mark as read functionality per notification and a Mark All as Read option
- Unread notifications reflected in the navbar bell icon badge count

---

### 3.8 Login / Signup Page
- Toggle between Login and Signup forms
- Login: email + password, with Forgot Password link
- Signup: name, email, password, confirm password
- OSS Google login option
- Form validation with inline error messages

---

### 3.9 Crack the Code Game Page
- Accessible from the navbar or a promotional banner
- Puzzle-based interaction: user solves a simple visual puzzle (e.g., arrange puzzle pieces or enter a code sequence)
- On success: a discount coupon code is revealed and can be copied directly
- Coupon is applicable at cart checkout
- Each user can play once per day; if already played today, the game page shows the remaining time until the next attempt

---

## 4. Business Rules & Logic

- **Theme toggle:** Dark/light mode preference is saved to local storage and applied automatically on subsequent visits. All UI components — cards, text, backgrounds, buttons, navbar, footer — adapt dynamically to the active theme.
- **Category filter:** Selecting a category on the home page filters the product grid to show only matching items; selecting the same category again resets the filter.
- **Advanced filters:** Price range, shoe size, brand, and color filters can be combined; results update dynamically. Clearing all filters restores the full product grid.
- **Cart persistence:** Cart contents persist across page navigation within the session; if the user is logged in, cart is saved to their account.
- **Discount display:** If a product has a discount, both original and discounted prices are shown; the discount percentage badge is calculated automatically.
- **Coupon application:** Only one coupon code can be applied per order; invalid or expired codes display an inline error message.
- **Crack the Code limit:** One play per user per day; if already played today, the game page shows the remaining time until the next attempt.
- **Wishlist:** Available to both guests (session-based) and logged-in users (account-based); guest wishlist is not persisted after session ends.
- **Order tracking:** Timeline reflects the current order status; statuses update in sequence and cannot go backwards.
- **Flash sale countdown:** When the timer reaches zero, the flash sale section is hidden or replaced with a next sale teaser.
- **Reviews:** Only logged-in users can submit reviews; each user can submit one review per product. Reviews are displayed immediately after submission.
- **Recently viewed:** Tracked per session for guests; persisted across sessions for logged-in users. Displays last 4–6 viewed products.
- **Trending section:** Populated based on frequently viewed or interacted-with products; updated dynamically.
- **Notifications:** Generated for order status changes and promotional events; unread count reflected in navbar badge. Marking as read updates the badge count in real time.
- **Product catalog:** Default catalog includes a wide variety of shoe designs across Sneakers, Sports, Casual, and Formal categories to ensure a visually rich homepage.

---

## 5. Exceptions & Edge Cases

| Scenario | Handling |
|---|---|
| Search returns no results | Display message: No shoes found. Try a different keyword. |
| Item out of stock | Show Out of Stock badge on card; Add to Cart button disabled |
| Cart is empty at checkout | Redirect to home with message: Your cart is empty. Start shopping! |
| Invalid coupon code entered | Inline error: Invalid or expired coupon code |
| User not logged in and tries to access Dashboard | Redirect to Login page with return URL preserved |
| Crack the Code already played today | Show countdown to next available attempt |
| Order tracking status unavailable | Display: Tracking information not yet available. Please check back later. |
| Network error on checkout submission | Display error toast and allow retry without data loss |
| Wishlist empty | Display: Your wishlist is empty. Start adding your favorites! |
| Review submission by guest | Prompt to log in before submitting a review |
| No recently viewed items | Recently Viewed section is hidden or shows a placeholder |
| Filters return no matching products | Display: No products match your selected filters. Try adjusting your filters. |
| Geolocation unavailable for address auto-fill | Address field remains a manual text input; no error shown |
| Notification list is empty | Display: No notifications yet. |

---

## 6. Acceptance Criteria

- Home page loads with navbar (including theme toggle, notification bell, wishlist icon, cart icon), hero banner slider, category tabs, trending shoes section, product grid with filter panel, flash sale section, AI recommendations, and recently viewed sections all visible and functional.
- Dark/light mode toggle switches all UI components dynamically; preference persists via local storage across sessions.
- Category tabs correctly filter the product grid.
- Advanced filters (price range, size, brand, color) dynamically update product grid results; active filters are shown as removable tags; Clear All resets filters.
- Hero banner auto-plays and supports manual navigation.
- Product cards display image, name, price, discount, rating, Add to Cart button, and wishlist toggle; clicking navigates to the product detail page.
- Add to Cart updates the cart icon badge count in real time.
- Wishlist toggle adds/removes items and updates the wishlist icon badge; Wishlist Page displays saved items with Move to Cart and Remove options.
- Cart page correctly lists items, supports quantity changes and removal, and applies valid coupon codes.
- Checkout page collects full name, phone number, address, and pincode; displays order summary before confirmation; Place Order triggers the order confirmation screen with order ID and summary.
- User Dashboard displays order list with status badges, order tracking timeline, and notifications with mark-as-read functionality.
- Login and Signup forms validate inputs and display inline errors; OSS Google login is functional.
- Product Detail Page displays reviews with average rating; logged-in users can submit a star rating and written review; guests are prompted to log in.
- Trending Shoes section displays popular products on the home page.
- Recently Viewed section tracks and displays last 4–6 viewed products; persists across sessions for logged-in users.
- Notification bell icon shows unread count badge; notification panel lists recent notifications with mark-as-read support.
- Crack the Code game reveals a valid coupon on success and enforces the once-per-day limit.
- Product catalog is rich by default with varied shoe designs across Sneakers, Sports, Casual, and Formal categories.
- Footer links are present and navigable.
- Layout is responsive across mobile, tablet, and desktop breakpoints.
- All components adapt correctly to both dark and light themes.

---

## 7. Out of Scope for This Version

- AI shoe size recommender
- AR camera try-on feature
- Voice search (multi-language: Telugu, Hindi, English)
- Village mode (low-data UI)
- Spin & Win discount wheel
- Real payment gateway integration (checkout uses placeholder payment options only)
- Backend order management or inventory system
- Admin dashboard or seller portal
- Multi-language localization beyond English
- Push notifications (web or mobile)
- Firebase or third-party backend integration (data stored via local storage or provided backend)
- Product review editing or deletion by users after submission