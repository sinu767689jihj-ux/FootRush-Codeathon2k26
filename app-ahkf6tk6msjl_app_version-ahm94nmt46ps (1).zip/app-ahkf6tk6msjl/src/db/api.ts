import { supabase } from './supabase';
import type { Product, Category, CartItem, WishlistItem, Order, OrderItem, Coupon, GameAttempt, Notification, RecentlyViewed, Review, ProductFilters } from '@/types';

// Categories
export async function getCategories(): Promise<Category[]> {
  const { data, error } = await supabase
    .from('categories')
    .select('*')
    .order('name');

  if (error) {
    console.error('Error fetching categories:', error);
    return [];
  }
  return Array.isArray(data) ? data : [];
}

// Products
export async function getProducts(categorySlug?: string, searchQuery?: string, filters?: ProductFilters): Promise<Product[]> {
  let query = supabase
    .from('products')
    .select('*')
    .eq('in_stock', true)
    .order('created_at', { ascending: false });

  if (categorySlug) {
    const { data: category } = await supabase
      .from('categories')
      .select('id')
      .eq('slug', categorySlug)
      .maybeSingle();
    
    if (category) {
      query = query.eq('category_id', category.id);
    }
  }

  if (searchQuery) {
    query = query.or(`name.ilike.%${searchQuery}%,brand.ilike.%${searchQuery}%,description.ilike.%${searchQuery}%`);
  }

  // Apply filters
  if (filters) {
    if (filters.minPrice !== undefined) {
      query = query.gte('price', filters.minPrice);
    }
    if (filters.maxPrice !== undefined) {
      query = query.lte('price', filters.maxPrice);
    }
    if (filters.brands && filters.brands.length > 0) {
      query = query.in('brand', filters.brands);
    }
  }

  const { data, error } = await query;

  if (error) {
    console.error('Error fetching products:', error);
    return [];
  }

  let products = Array.isArray(data) ? data : [];

  // Client-side filtering for arrays
  if (filters) {
    if (filters.sizes && filters.sizes.length > 0) {
      products = products.filter(p => 
        p.sizes && p.sizes.some((size: string) => filters.sizes?.includes(size))
      );
    }
    if (filters.colors && filters.colors.length > 0) {
      products = products.filter(p => 
        p.colors && p.colors.some((color: string) => filters.colors?.includes(color))
      );
    }
  }

  return products;
}

export async function getProductById(id: string): Promise<Product | null> {
  const { data, error } = await supabase
    .from('products')
    .select('*')
    .eq('id', id)
    .maybeSingle();

  if (error) {
    console.error('Error fetching product:', error);
    return null;
  }
  return data;
}

export async function getFlashSaleProducts(): Promise<Product[]> {
  const { data, error } = await supabase
    .from('products')
    .select('*')
    .eq('is_flash_sale', true)
    .eq('in_stock', true)
    .gt('flash_sale_ends_at', new Date().toISOString())
    .order('flash_sale_ends_at')
    .limit(10);

  if (error) {
    console.error('Error fetching flash sale products:', error);
    return [];
  }
  return Array.isArray(data) ? data : [];
}

// Cart
export async function getCartItems(userId: string): Promise<CartItem[]> {
  const { data, error } = await supabase
    .from('cart_items')
    .select('*, product:products(*)')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching cart items:', error);
    return [];
  }
  return Array.isArray(data) ? data : [];
}

export async function addToCart(userId: string, productId: string, size: string, quantity: number = 1) {
  const { data: existing } = await supabase
    .from('cart_items')
    .select('*')
    .eq('user_id', userId)
    .eq('product_id', productId)
    .eq('size', size)
    .maybeSingle();

  if (existing) {
    const { error } = await supabase
      .from('cart_items')
      .update({ quantity: existing.quantity + quantity, updated_at: new Date().toISOString() })
      .eq('id', existing.id);

    if (error) {
      console.error('Error updating cart item:', error);
      return { error };
    }
    return { error: null };
  }

  const { error } = await supabase
    .from('cart_items')
    .insert({ user_id: userId, product_id: productId, size, quantity });

  if (error) {
    console.error('Error adding to cart:', error);
    return { error };
  }
  return { error: null };
}

export async function updateCartItemQuantity(itemId: string, quantity: number) {
  const { error } = await supabase
    .from('cart_items')
    .update({ quantity, updated_at: new Date().toISOString() })
    .eq('id', itemId);

  if (error) {
    console.error('Error updating cart item quantity:', error);
    return { error };
  }
  return { error: null };
}

export async function removeFromCart(itemId: string) {
  const { error } = await supabase
    .from('cart_items')
    .delete()
    .eq('id', itemId);

  if (error) {
    console.error('Error removing from cart:', error);
    return { error };
  }
  return { error: null };
}

export async function clearCart(userId: string) {
  const { error } = await supabase
    .from('cart_items')
    .delete()
    .eq('user_id', userId);

  if (error) {
    console.error('Error clearing cart:', error);
    return { error };
  }
  return { error: null };
}

// Wishlist
export async function getWishlistItems(userId: string): Promise<WishlistItem[]> {
  const { data, error } = await supabase
    .from('wishlist_items')
    .select('*, product:products(*)')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching wishlist items:', error);
    return [];
  }
  return Array.isArray(data) ? data : [];
}

export async function addToWishlist(userId: string, productId: string) {
  const { error } = await supabase
    .from('wishlist_items')
    .insert({ user_id: userId, product_id: productId });

  if (error) {
    console.error('Error adding to wishlist:', error);
    return { error };
  }
  return { error: null };
}

export async function removeFromWishlist(userId: string, productId: string) {
  const { error } = await supabase
    .from('wishlist_items')
    .delete()
    .eq('user_id', userId)
    .eq('product_id', productId);

  if (error) {
    console.error('Error removing from wishlist:', error);
    return { error };
  }
  return { error: null };
}

export async function isInWishlist(userId: string, productId: string): Promise<boolean> {
  const { data } = await supabase
    .from('wishlist_items')
    .select('id')
    .eq('user_id', userId)
    .eq('product_id', productId)
    .maybeSingle();

  return !!data;
}

// Orders
export async function createOrder(orderData: {
  user_id: string;
  total_amount: number;
  discount_amount: number;
  coupon_code: string | null;
  delivery_name: string;
  delivery_address: string;
  delivery_phone: string;
  payment_method: string;
}, items: { product_id: string; product_name: string; product_image: string; size: string; quantity: number; price: number }[]) {
  const { data: order, error: orderError } = await supabase
    .from('orders')
    .insert(orderData)
    .select()
    .single();

  if (orderError) {
    console.error('Error creating order:', orderError);
    return { error: orderError };
  }

  const orderItems = items.map(item => ({
    order_id: order.id,
    ...item
  }));

  const { error: itemsError } = await supabase
    .from('order_items')
    .insert(orderItems);

  if (itemsError) {
    console.error('Error creating order items:', itemsError);
    return { error: itemsError };
  }

  return { data: order, error: null };
}

export async function getOrders(userId: string): Promise<Order[]> {
  const { data, error } = await supabase
    .from('orders')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching orders:', error);
    return [];
  }
  return Array.isArray(data) ? data : [];
}

export async function getOrderById(orderId: string): Promise<Order | null> {
  const { data, error } = await supabase
    .from('orders')
    .select('*')
    .eq('id', orderId)
    .maybeSingle();

  if (error) {
    console.error('Error fetching order:', error);
    return null;
  }
  return data;
}

export async function getOrderItems(orderId: string): Promise<OrderItem[]> {
  const { data, error } = await supabase
    .from('order_items')
    .select('*')
    .eq('order_id', orderId)
    .order('created_at');

  if (error) {
    console.error('Error fetching order items:', error);
    return [];
  }
  return Array.isArray(data) ? data : [];
}

// Coupons
export async function validateCoupon(code: string): Promise<Coupon | null> {
  const { data, error } = await supabase
    .from('coupons')
    .select('*')
    .eq('code', code)
    .eq('is_active', true)
    .maybeSingle();

  if (error) {
    console.error('Error validating coupon:', error);
    return null;
  }

  if (data && data.expires_at && new Date(data.expires_at) < new Date()) {
    return null;
  }

  return data;
}

// Game
export async function checkGameAttemptToday(userId: string): Promise<boolean> {
  const today = new Date().toISOString().split('T')[0];
  const { data } = await supabase
    .from('game_attempts')
    .select('id')
    .eq('user_id', userId)
    .eq('played_date', today)
    .maybeSingle();

  return !!data;
}

export async function createGameAttempt(userId: string, couponCode: string) {
  const { error } = await supabase
    .from('game_attempts')
    .insert({ user_id: userId, coupon_code: couponCode });

  if (error) {
    console.error('Error creating game attempt:', error);
    return { error };
  }
  return { error: null };
}

// Notifications
export async function getNotifications(userId: string): Promise<Notification[]> {
  const { data, error } = await supabase
    .from('notifications')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(20);

  if (error) {
    console.error('Error fetching notifications:', error);
    return [];
  }
  return Array.isArray(data) ? data : [];
}

export async function markNotificationAsRead(notificationId: string) {
  const { error } = await supabase
    .from('notifications')
    .update({ is_read: true })
    .eq('id', notificationId);

  if (error) {
    console.error('Error marking notification as read:', error);
    return { error };
  }
  return { error: null };
}

// Recently Viewed
export async function addToRecentlyViewed(userId: string, productId: string) {
  const { data: existing } = await supabase
    .from('recently_viewed')
    .select('id')
    .eq('user_id', userId)
    .eq('product_id', productId)
    .maybeSingle();

  if (existing) {
    const { error } = await supabase
      .from('recently_viewed')
      .update({ viewed_at: new Date().toISOString() })
      .eq('id', existing.id);

    if (error) {
      console.error('Error updating recently viewed:', error);
    }
    return;
  }

  const { error } = await supabase
    .from('recently_viewed')
    .insert({ user_id: userId, product_id: productId });

  if (error) {
    console.error('Error adding to recently viewed:', error);
  }
}

export async function getRecentlyViewed(userId: string): Promise<RecentlyViewed[]> {
  const { data, error } = await supabase
    .from('recently_viewed')
    .select('*, product:products(*)')
    .eq('user_id', userId)
    .order('viewed_at', { ascending: false })
    .limit(6);

  if (error) {
    console.error('Error fetching recently viewed:', error);
    return [];
  }
  return Array.isArray(data) ? data : [];
}

// Reviews
export async function getProductReviews(productId: string): Promise<Review[]> {
  const { data, error } = await supabase
    .from('reviews')
    .select('*, profile:profiles(username)')
    .eq('product_id', productId)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching reviews:', error);
    return [];
  }
  return Array.isArray(data) ? data : [];
}

export async function createReview(userId: string, productId: string, rating: number, comment: string) {
  const { error } = await supabase
    .from('reviews')
    .insert({ user_id: userId, product_id: productId, rating, comment: comment || null });

  if (error) {
    console.error('Error creating review:', error);
    return { error };
  }
  return { error: null };
}

export async function updateReview(reviewId: string, rating: number, comment: string) {
  const { error } = await supabase
    .from('reviews')
    .update({ rating, comment: comment || null, updated_at: new Date().toISOString() })
    .eq('id', reviewId);

  if (error) {
    console.error('Error updating review:', error);
    return { error };
  }
  return { error: null };
}

export async function getUserReview(userId: string, productId: string): Promise<Review | null> {
  const { data, error } = await supabase
    .from('reviews')
    .select('*')
    .eq('user_id', userId)
    .eq('product_id', productId)
    .maybeSingle();

  if (error) {
    console.error('Error fetching user review:', error);
    return null;
  }
  return data;
}

// Trending Products
export async function getTrendingProducts(): Promise<Product[]> {
  const { data, error } = await supabase
    .from('products')
    .select('*')
    .eq('in_stock', true)
    .order('view_count', { ascending: false })
    .limit(8);

  if (error) {
    console.error('Error fetching trending products:', error);
    return [];
  }
  return Array.isArray(data) ? data : [];
}

export async function incrementProductViewCount(productId: string) {
  const { error } = await supabase.rpc('increment_view_count', { product_id: productId });
  
  if (error) {
    console.error('Error incrementing view count:', error);
  }
}

// Get unique brands and colors for filters
export async function getProductBrands(): Promise<string[]> {
  const { data, error } = await supabase
    .from('products')
    .select('brand')
    .not('brand', 'is', null)
    .order('brand');

  if (error) {
    console.error('Error fetching brands:', error);
    return [];
  }

  const brands = Array.from(new Set(data.map(p => p.brand).filter(Boolean))) as string[];
  return brands;
}

export async function getProductColors(): Promise<string[]> {
  const { data, error } = await supabase
    .from('products')
    .select('colors');

  if (error) {
    console.error('Error fetching colors:', error);
    return [];
  }

  const allColors = data.flatMap(p => p.colors || []);
  const uniqueColors = Array.from(new Set(allColors));
  return uniqueColors.sort();
}
