import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const slides = [
  {
    id: 1,
    title: 'Summer Collection',
    subtitle: 'Up to 50% OFF',
    description: 'Get ready for summer with our latest collection',
    image: 'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_7b1601f0-d308-43a8-af0a-009349798d6a.jpg'
  },
  {
    id: 2,
    title: 'New Arrivals',
    subtitle: 'Fresh Styles',
    description: 'Discover the latest trends in footwear',
    image: 'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_c75c8f91-a615-4a84-8d3d-a302e5fc5964.jpg'
  },
  {
    id: 3,
    title: 'Premium Collection',
    subtitle: 'Luxury Comfort',
    description: 'Experience premium quality and style',
    image: 'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_78ade549-fe68-45fa-b3bb-4d78fdb64f2e.jpg'
  }
];

export function HeroSlider() {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);

    return () => clearInterval(timer);
  }, []);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  return (
    <div className="relative w-full h-[400px] md:h-[500px] overflow-hidden rounded-lg bg-muted">
      {slides.map((slide, index) => (
        <div
          key={slide.id}
          className={`absolute inset-0 transition-opacity duration-500 ${
            index === currentSlide ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <div className="relative w-full h-full">
            <img
              src={slide.image}
              alt={slide.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-background/90 to-background/20">
              <div className="container mx-auto px-4 h-full flex items-center">
                <div className="max-w-xl space-y-4">
                  <h2 className="text-4xl md:text-6xl font-bold gradient-text">
                    {slide.title}
                  </h2>
                  <p className="text-2xl md:text-3xl font-semibold text-primary">
                    {slide.subtitle}
                  </p>
                  <p className="text-lg text-muted-foreground">
                    {slide.description}
                  </p>
                  <Button size="lg" className="mt-4" asChild>
                    <a href="/">Shop Now</a>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      ))}

      {/* Navigation Buttons */}
      <Button
        variant="ghost"
        size="icon"
        className="absolute left-4 top-1/2 -translate-y-1/2 bg-background/80 hover:bg-background"
        onClick={prevSlide}
      >
        <ChevronLeft className="h-6 w-6" />
      </Button>
      <Button
        variant="ghost"
        size="icon"
        className="absolute right-4 top-1/2 -translate-y-1/2 bg-background/80 hover:bg-background"
        onClick={nextSlide}
      >
        <ChevronRight className="h-6 w-6" />
      </Button>

      {/* Indicators */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
        {slides.map((_, index) => (
          <button
            key={index}
            className={`w-2 h-2 rounded-full transition-all ${
              index === currentSlide ? 'bg-primary w-8' : 'bg-muted-foreground/50'
            }`}
            onClick={() => setCurrentSlide(index)}
          />
        ))}
      </div>
    </div>
  );
}
