import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Heart, ShoppingCart, Star } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { addToCart, addToWishlist, removeFromWishlist, isInWishlist } from '@/db/api';
import type { Product } from '@/types';

interface ProductCardProps {
  product: Product;
  onUpdate?: () => void;
}

export function ProductCard({ product, onUpdate }: ProductCardProps) {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) {
      checkWishlistStatus();
    }
  }, [user, product.id]);

  const checkWishlistStatus = async () => {
    if (!user) return;
    const status = await isInWishlist(user.id, product.id);
    setIsWishlisted(status);
  };

  const discountedPrice = product.price * (1 - product.discount_percentage / 100);

  const handleAddToCart = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!user) {
      navigate('/login');
      return;
    }

    if (!product.sizes || product.sizes.length === 0) {
      toast.error('No sizes available');
      return;
    }

    setLoading(true);
    const { error } = await addToCart(user.id, product.id, product.sizes[0], 1);
    setLoading(false);

    if (error) {
      toast.error('Failed to add to cart');
    } else {
      toast.success('Added to cart');
      onUpdate?.();
    }
  };

  const handleToggleWishlist = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!user) {
      navigate('/login');
      return;
    }

    setLoading(true);
    if (isWishlisted) {
      const { error } = await removeFromWishlist(user.id, product.id);
      if (!error) {
        setIsWishlisted(false);
        toast.success('Removed from wishlist');
        onUpdate?.();
      }
    } else {
      const { error } = await addToWishlist(user.id, product.id);
      if (!error) {
        setIsWishlisted(true);
        toast.success('Added to wishlist');
        onUpdate?.();
      }
    }
    setLoading(false);
  };

  return (
    <Card 
      className="group cursor-pointer hover:shadow-lg transition-all duration-300 overflow-hidden"
      onClick={() => navigate(`/product/${product.id}`)}
    >
      <div className="relative aspect-square overflow-hidden bg-muted">
        <img
          src={product.image_url}
          alt={product.name}
          className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-300"
        />
        {product.discount_percentage > 0 && (
          <Badge className="absolute top-2 left-2 bg-primary text-primary-foreground">
            {product.discount_percentage}% OFF
          </Badge>
        )}
        {product.is_flash_sale && (
          <Badge className="absolute top-2 right-2 bg-destructive text-destructive-foreground">
            ⚡ Flash Sale
          </Badge>
        )}
        <Button
          variant="ghost"
          size="icon"
          className={`absolute top-2 right-2 ${product.is_flash_sale ? 'top-12' : ''} bg-background/80 hover:bg-background ${isWishlisted ? 'text-destructive' : ''}`}
          onClick={handleToggleWishlist}
          disabled={loading}
        >
          <Heart className={`h-4 w-4 ${isWishlisted ? 'fill-current' : ''}`} />
        </Button>
      </div>
      <CardContent className="p-4 space-y-2">
        <div className="space-y-1">
          <h3 className="font-semibold line-clamp-1">{product.name}</h3>
          {product.brand && (
            <p className="text-sm text-muted-foreground">{product.brand}</p>
          )}
        </div>
        <div className="flex items-center gap-1">
          <Star className="h-4 w-4 fill-primary text-primary" />
          <span className="text-sm font-medium">{product.rating}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-lg font-bold text-primary">
            ${discountedPrice.toFixed(2)}
          </span>
          {product.discount_percentage > 0 && (
            <span className="text-sm text-muted-foreground line-through">
              ${product.price.toFixed(2)}
            </span>
          )}
        </div>
        <Button
          className="w-full"
          onClick={handleAddToCart}
          disabled={loading || !product.in_stock}
        >
          {product.in_stock ? (
            <>
              <ShoppingCart className="h-4 w-4 mr-2" />
              Add to Cart
            </>
          ) : (
            'Out of Stock'
          )}
        </Button>
      </CardContent>
    </Card>
  );
}
