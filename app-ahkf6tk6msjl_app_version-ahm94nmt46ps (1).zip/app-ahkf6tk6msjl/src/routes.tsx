import HomePage from './pages/HomePage';
import ProductDetailPage from './pages/ProductDetailPage';
import CartPage from './pages/CartPage';
import CheckoutPage from './pages/CheckoutPage';
import DashboardPage from './pages/DashboardPage';
import LoginPage from './pages/LoginPage';
import GamePage from './pages/GamePage';
import AboutPage from './pages/AboutPage';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Home',
    path: '/',
    element: <HomePage />
  },
  {
    name: 'About',
    path: '/about',
    element: <AboutPage />
  },
  {
    name: 'Product Detail',
    path: '/product/:id',
    element: <ProductDetailPage />,
    visible: false
  },
  {
    name: 'Cart',
    path: '/cart',
    element: <CartPage />,
    visible: false
  },
  {
    name: 'Checkout',
    path: '/checkout',
    element: <CheckoutPage />,
    visible: false
  },
  {
    name: 'Dashboard',
    path: '/dashboard',
    element: <DashboardPage />,
    visible: false
  },
  {
    name: 'Login',
    path: '/login',
    element: <LoginPage />,
    visible: false
  },
  {
    name: 'Game',
    path: '/game',
    element: <GamePage />
  }
];

export default routes;
