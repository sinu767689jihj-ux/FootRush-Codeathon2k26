import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { getCartItems, createOrder, clearCart } from '@/db/api';
import type { CartItem } from '@/types';

export default function CheckoutPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(false);
  
  const { appliedCoupon, total, subtotal, couponDiscount } = location.state || {};

  const [formData, setFormData] = useState({
    name: '',
    address: '',
    phone: '',
    paymentMethod: 'card'
  });

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    loadCart();
  }, [user]);

  const loadCart = async () => {
    if (!user) return;
    const items = await getCartItems(user.id);
    if (items.length === 0) {
      toast.error('Your cart is empty');
      navigate('/');
      return;
    }
    setCartItems(items);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) return;

    if (!formData.name || !formData.address || !formData.phone) {
      toast.error('Please fill in all fields');
      return;
    }

    setLoading(true);

    const orderItems = cartItems.map(item => ({
      product_id: item.product_id,
      product_name: item.product?.name || '',
      product_image: item.product?.image_url || '',
      size: item.size,
      quantity: item.quantity,
      price: item.product ? item.product.price * (1 - item.product.discount_percentage / 100) : 0
    }));

    const { data: order, error } = await createOrder(
      {
        user_id: user.id,
        total_amount: total || subtotal || 0,
        discount_amount: couponDiscount || 0,
        coupon_code: appliedCoupon?.code || null,
        delivery_name: formData.name,
        delivery_address: formData.address,
        delivery_phone: formData.phone,
        payment_method: formData.paymentMethod
      },
      orderItems
    );

    if (error) {
      toast.error('Failed to place order');
      setLoading(false);
      return;
    }

    await clearCart(user.id);
    toast.success('Order placed successfully!');
    navigate(`/dashboard?tab=orders`);
  };

  const calculatedSubtotal = cartItems.reduce((sum, item) => {
    if (!item.product) return sum;
    const price = item.product.price * (1 - item.product.discount_percentage / 100);
    return sum + price * item.quantity;
  }, 0);

  const finalSubtotal = subtotal || calculatedSubtotal;
  const finalCouponDiscount = couponDiscount || 0;
  const finalTotal = total || finalSubtotal;

  return (
    <div className="min-h-screen">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Checkout</h1>

        <div className="grid md:grid-cols-3 gap-8">
          {/* Checkout Form */}
          <div className="md:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Delivery Information</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="address">Delivery Address</Label>
                    <Input
                      id="address"
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Payment Method</Label>
                    <RadioGroup
                      value={formData.paymentMethod}
                      onValueChange={(value) => setFormData({ ...formData, paymentMethod: value })}
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="card" id="card" />
                        <Label htmlFor="card" className="cursor-pointer">Credit/Debit Card</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="upi" id="upi" />
                        <Label htmlFor="upi" className="cursor-pointer">UPI</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="cod" id="cod" />
                        <Label htmlFor="cod" className="cursor-pointer">Cash on Delivery</Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <Button type="submit" className="w-full" size="lg" disabled={loading}>
                    <Lock className="h-4 w-4 mr-2" />
                    {loading ? 'Processing...' : 'Place Order'}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Order Summary */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  {cartItems.map((item) => {
                    if (!item.product) return null;
                    const price = item.product.price * (1 - item.product.discount_percentage / 100);
                    return (
                      <div key={item.id} className="flex justify-between text-sm">
                        <span className="text-muted-foreground">
                          {item.product.name} x {item.quantity}
                        </span>
                        <span>${(price * item.quantity).toFixed(2)}</span>
                      </div>
                    );
                  })}
                </div>

                <Separator />

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span>${finalSubtotal.toFixed(2)}</span>
                  </div>
                  {finalCouponDiscount > 0 && (
                    <div className="flex justify-between text-primary">
                      <span>Discount</span>
                      <span>-${finalCouponDiscount.toFixed(2)}</span>
                    </div>
                  )}
                </div>

                <Separator />

                <div className="flex justify-between text-lg font-bold">
                  <span>Total</span>
                  <span className="text-primary">${finalTotal.toFixed(2)}</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
