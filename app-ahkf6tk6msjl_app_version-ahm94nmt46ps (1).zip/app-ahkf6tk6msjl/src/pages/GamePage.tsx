import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Lock, Unlock, Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { checkGameAttemptToday, createGameAttempt } from '@/db/api';

const PUZZLE_CODES = [
  { question: '10 + 5 = ?', answer: '15', coupon: 'GAME15' },
  { question: 'FOOT + RUSH = ?', answer: 'FOOTRUSH', coupon: 'RUSH20' },
  { question: 'First letter of GREEN?', answer: 'G', coupon: 'GREEN25' },
  { question: '2 × 10 = ?', answer: '20', coupon: 'DOUBLE20' },
  { question: 'SHOE backwards?', answer: 'EOHS', coupon: 'FLIP30' }
];

export default function GamePage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [hasPlayedToday, setHasPlayedToday] = useState(false);
  const [gameStarted, setGameStarted] = useState(false);
  const [currentPuzzle, setCurrentPuzzle] = useState(PUZZLE_CODES[0]);
  const [userAnswer, setUserAnswer] = useState('');
  const [revealedCoupon, setRevealedCoupon] = useState('');
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    checkAttempt();
  }, [user]);

  const checkAttempt = async () => {
    if (!user) return;
    setLoading(true);
    const played = await checkGameAttemptToday(user.id);
    setHasPlayedToday(played);
    setLoading(false);
  };

  const handleStartGame = () => {
    const randomPuzzle = PUZZLE_CODES[Math.floor(Math.random() * PUZZLE_CODES.length)];
    setCurrentPuzzle(randomPuzzle);
    setGameStarted(true);
    setUserAnswer('');
    setRevealedCoupon('');
  };

  const handleSubmitAnswer = async () => {
    if (!user) return;

    if (userAnswer.trim().toUpperCase() === currentPuzzle.answer.toUpperCase()) {
      setRevealedCoupon(currentPuzzle.coupon);
      const { error } = await createGameAttempt(user.id, currentPuzzle.coupon);
      if (!error) {
        setHasPlayedToday(true);
        toast.success('Congratulations! You cracked the code!');
      }
    } else {
      toast.error('Wrong answer! Try again.');
      setUserAnswer('');
    }
  };

  const handleCopyCoupon = () => {
    navigator.clipboard.writeText(revealedCoupon);
    setCopied(true);
    toast.success('Coupon code copied!');
    setTimeout(() => setCopied(false), 2000);
  };

  const getTimeUntilMidnight = () => {
    const now = new Date();
    const midnight = new Date();
    midnight.setHours(24, 0, 0, 0);
    const diff = midnight.getTime() - now.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Loading...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center">
              {revealedCoupon ? (
                <Unlock className="h-10 w-10 text-primary" />
              ) : (
                <Lock className="h-10 w-10 text-primary" />
              )}
            </div>
          </div>
          <CardTitle className="text-3xl gradient-text">🎮 Crack the Code</CardTitle>
          <CardDescription>
            Solve the puzzle to unlock exclusive discount coupons!
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {hasPlayedToday && !revealedCoupon ? (
            <div className="text-center space-y-4 py-8">
              <p className="text-lg font-medium">You've already played today!</p>
              <p className="text-muted-foreground">
                Come back in <span className="font-bold text-primary">{getTimeUntilMidnight()}</span> to play again
              </p>
              <Button onClick={() => navigate('/')}>
                Continue Shopping
              </Button>
            </div>
          ) : revealedCoupon ? (
            <div className="text-center space-y-6 py-8">
              <div className="space-y-2">
                <p className="text-2xl font-bold text-primary">🎉 Congratulations!</p>
                <p className="text-muted-foreground">You've unlocked a discount coupon!</p>
              </div>
              
              <div className="bg-muted p-6 rounded-lg space-y-4">
                <p className="text-sm text-muted-foreground">Your Coupon Code</p>
                <div className="flex items-center justify-center gap-2">
                  <code className="text-3xl font-bold tracking-wider">{revealedCoupon}</code>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={handleCopyCoupon}
                  >
                    {copied ? (
                      <Check className="h-5 w-5 text-primary" />
                    ) : (
                      <Copy className="h-5 w-5" />
                    )}
                  </Button>
                </div>
                <p className="text-sm text-muted-foreground">
                  Use this code at checkout to get your discount!
                </p>
              </div>

              <div className="flex gap-3">
                <Button className="flex-1" onClick={() => navigate('/cart')}>
                  Go to Cart
                </Button>
                <Button variant="outline" className="flex-1" onClick={() => navigate('/')}>
                  Continue Shopping
                </Button>
              </div>
            </div>
          ) : gameStarted ? (
            <div className="space-y-6">
              <div className="bg-muted p-8 rounded-lg text-center">
                <p className="text-sm text-muted-foreground mb-4">Solve this puzzle:</p>
                <p className="text-2xl font-bold">{currentPuzzle.question}</p>
              </div>

              <div className="space-y-4">
                <Input
                  placeholder="Enter your answer"
                  value={userAnswer}
                  onChange={(e) => setUserAnswer(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSubmitAnswer()}
                  className="text-center text-lg"
                />
                <Button className="w-full" size="lg" onClick={handleSubmitAnswer}>
                  Submit Answer
                </Button>
              </div>

              <div className="text-center">
                <Button variant="ghost" onClick={() => setGameStarted(false)}>
                  Try Different Puzzle
                </Button>
              </div>
            </div>
          ) : (
            <div className="text-center space-y-6 py-8">
              <div className="space-y-2">
                <p className="text-lg">Ready to unlock your discount?</p>
                <p className="text-muted-foreground">
                  Solve a simple puzzle and get an exclusive coupon code!
                </p>
              </div>

              <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
                <div className="p-4 bg-muted rounded-lg">
                  <p className="text-2xl font-bold text-primary">15%</p>
                  <p className="text-xs text-muted-foreground">OFF</p>
                </div>
                <div className="p-4 bg-muted rounded-lg">
                  <p className="text-2xl font-bold text-primary">20%</p>
                  <p className="text-xs text-muted-foreground">OFF</p>
                </div>
                <div className="p-4 bg-muted rounded-lg">
                  <p className="text-2xl font-bold text-primary">30%</p>
                  <p className="text-xs text-muted-foreground">OFF</p>
                </div>
              </div>

              <Button size="lg" onClick={handleStartGame}>
                Start Game
              </Button>

              <p className="text-sm text-muted-foreground">
                ⏰ You can play once per day
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
