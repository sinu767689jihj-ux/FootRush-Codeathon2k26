import { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { HeroSlider } from '@/components/products/HeroSlider';
import { CategoryTabs } from '@/components/products/CategoryTabs';
import { ProductCard } from '@/components/products/ProductCard';
import { FilterPanel } from '@/components/products/FilterPanel';
import { Skeleton } from '@/components/ui/skeleton';
import { getProducts, getFlashSaleProducts, getRecentlyViewed, getTrendingProducts } from '@/db/api';
import { useAuth } from '@/contexts/AuthContext';
import type { Product, RecentlyViewed, ProductFilters } from '@/types';

export default function HomePage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [flashSaleProducts, setFlashSaleProducts] = useState<Product[]>([]);
  const [trendingProducts, setTrendingProducts] = useState<Product[]>([]);
  const [recentlyViewed, setRecentlyViewed] = useState<RecentlyViewed[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [filters, setFilters] = useState<ProductFilters>({});
  const [loading, setLoading] = useState(true);
  const [flashSaleEndTime, setFlashSaleEndTime] = useState<Date | null>(null);

  const searchQuery = searchParams.get('search');

  const handleCategoryChange = (slug: string | null) => {
    setSelectedCategory(slug);
    // Reset filters when category changes
    setFilters({});
    // Clear search params when category changes
    if (searchQuery) {
      navigate('/');
    }
  };

  useEffect(() => {
    loadData();
  }, [selectedCategory, searchQuery, user, filters]);

  const loadData = async () => {
    setLoading(true);
    const [productsData, flashData, trendingData] = await Promise.all([
      getProducts(selectedCategory || undefined, searchQuery || undefined, filters),
      getFlashSaleProducts(),
      getTrendingProducts()
    ]);
    
    setProducts(productsData);
    setFlashSaleProducts(flashData);
    setTrendingProducts(trendingData);
    
    if (flashData.length > 0 && flashData[0].flash_sale_ends_at) {
      setFlashSaleEndTime(new Date(flashData[0].flash_sale_ends_at));
    }

    if (user) {
      const recentData = await getRecentlyViewed(user.id);
      setRecentlyViewed(recentData);
    }
    
    setLoading(false);
  };

  const FlashSaleCountdown = () => {
    const [timeLeft, setTimeLeft] = useState('');

    useEffect(() => {
      if (!flashSaleEndTime) return;

      const timer = setInterval(() => {
        const now = new Date().getTime();
        const distance = flashSaleEndTime.getTime() - now;

        if (distance < 0) {
          setTimeLeft('EXPIRED');
          clearInterval(timer);
          return;
        }

        const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);

        setTimeLeft(`${hours}h ${minutes}m ${seconds}s`);
      }, 1000);

      return () => clearInterval(timer);
    }, []);

    return timeLeft ? (
      <span className="text-destructive font-mono font-bold">{timeLeft}</span>
    ) : null;
  };

  return (
    <div className="min-h-screen">
      <div className="container mx-auto px-4 py-6 space-y-8">
        {/* Hero Slider */}
        <HeroSlider />

        {/* Category Tabs */}
        <div>
          <h2 className="text-2xl font-bold mb-4">Shop by Category</h2>
          <CategoryTabs
            selectedCategory={selectedCategory}
            onCategoryChange={handleCategoryChange}
          />
        </div>

        {/* Flash Sale Section */}
        {flashSaleProducts.length > 0 && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">⚡ Flash Sale</h2>
              {flashSaleEndTime && <FlashSaleCountdown />}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {flashSaleProducts.map((product) => (
                <ProductCard key={product.id} product={product} onUpdate={loadData} />
              ))}
            </div>
          </div>
        )}

        {/* Main Product Grid */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold">
              {searchQuery 
                ? `Search Results for "${searchQuery}"` 
                : selectedCategory 
                  ? `${selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)} Shoes`
                  : 'All Products'}
            </h2>
            <FilterPanel filters={filters} onFiltersChange={setFilters} />
          </div>
          
          <div className="flex gap-6">
            {/* Desktop Filter Sidebar */}
            <FilterPanel filters={filters} onFiltersChange={setFilters} />
            
            {/* Products Grid */}
            <div className="flex-1">
              {loading ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-6">
                  {[...Array(9)].map((_, i) => (
                    <div key={i} className="space-y-4">
                      <Skeleton className="aspect-square w-full bg-muted" />
                      <Skeleton className="h-4 w-3/4 bg-muted" />
                      <Skeleton className="h-4 w-1/2 bg-muted" />
                    </div>
                  ))}
                </div>
              ) : products.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-muted-foreground">
                    {searchQuery
                      ? 'No shoes found. Try a different keyword.'
                      : 'No products available.'}
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                  {products.map((product) => (
                    <ProductCard key={product.id} product={product} onUpdate={loadData} />
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Trending Section */}
        {trendingProducts.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-2xl font-bold">🔥 Trending Shoes</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {trendingProducts.map((product) => (
                <ProductCard key={product.id} product={product} onUpdate={loadData} />
              ))}
            </div>
          </div>
        )}

        {/* Recently Viewed Section */}
        {user && recentlyViewed.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-2xl font-bold">Recently Viewed</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {recentlyViewed.map((item) => (
                item.product ? (
                  <ProductCard key={item.id} product={item.product} onUpdate={loadData} />
                ) : null
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
