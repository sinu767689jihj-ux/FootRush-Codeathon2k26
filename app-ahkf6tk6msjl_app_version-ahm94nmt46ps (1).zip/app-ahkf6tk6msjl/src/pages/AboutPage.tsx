import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { ShoppingBag, Award, Truck, Shield } from 'lucide-react';

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-12 space-y-12">
        {/* Hero Section */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl md:text-5xl font-bold gradient-text">About Foot Rush</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Your ultimate destination for premium footwear. We bring you the latest trends, 
            unbeatable quality, and exceptional service.
          </p>
        </div>

        <Separator />

        {/* Our Story */}
        <div className="max-w-4xl mx-auto space-y-6">
          <h2 className="text-3xl font-bold text-center">Our Story</h2>
          <Card>
            <CardContent className="pt-6">
              <p className="text-muted-foreground leading-relaxed">
                Founded with a passion for footwear and a commitment to customer satisfaction, 
                Foot Rush has grown to become a trusted name in the online shoe retail industry. 
                We believe that the right pair of shoes can transform not just your outfit, but 
                your entire day. That's why we carefully curate our collection to include only 
                the best brands and styles, ensuring that every step you take is comfortable, 
                stylish, and confident.
              </p>
              <p className="text-muted-foreground leading-relaxed mt-4">
                Our platform combines cutting-edge technology with a user-friendly shopping 
                experience, featuring gamified discounts, personalized recommendations, and 
                seamless checkout. We're not just selling shoes – we're building a community 
                of shoe enthusiasts who appreciate quality, style, and innovation.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Features */}
        <div className="space-y-6">
          <h2 className="text-3xl font-bold text-center">Why Choose Foot Rush?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader>
                <ShoppingBag className="h-12 w-12 text-primary mb-2" />
                <CardTitle>Wide Selection</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Browse through hundreds of styles from top brands for men, women, and kids.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Award className="h-12 w-12 text-primary mb-2" />
                <CardTitle>Premium Quality</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Every product is carefully selected to meet our high standards of quality and durability.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Truck className="h-12 w-12 text-primary mb-2" />
                <CardTitle>Fast Delivery</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Quick and reliable shipping with real-time order tracking to your doorstep.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Shield className="h-12 w-12 text-primary mb-2" />
                <CardTitle>Secure Shopping</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Your data is protected with industry-standard security measures and encryption.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Mission & Vision */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">Our Mission</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                To provide customers with an exceptional online shopping experience by offering 
                high-quality footwear, innovative features, and outstanding customer service. 
                We strive to make shoe shopping fun, easy, and rewarding for everyone.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">Our Vision</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                To become the world's most loved online footwear destination, known for our 
                curated selection, customer-first approach, and innovative shopping features 
                that set new standards in e-commerce.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Contact Info */}
        <div className="max-w-2xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl text-center">Get in Touch</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center space-y-2">
                <p className="text-muted-foreground">
                  Have questions or feedback? We'd love to hear from you!
                </p>
                <div className="space-y-1">
                  <p className="font-medium">Email: support@footrush.com</p>
                  <p className="font-medium">Phone: +1 (555) 123-4567</p>
                  <p className="font-medium">Address: 123 Shoe Street, Fashion District, NY 10001</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
