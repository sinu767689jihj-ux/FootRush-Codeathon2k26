-- Insert categories
INSERT INTO categories (name, slug) VALUES
  ('Men', 'men'),
  ('Women', 'women'),
  ('Kids', 'kids'),
  ('Sports', 'sports'),
  ('Sneakers', 'sneakers');

-- Insert products
INSERT INTO products (name, description, brand, category_id, price, discount_percentage, rating, image_url, sizes, in_stock, is_flash_sale, flash_sale_ends_at) VALUES
  (
    'Athletic Runner Pro',
    'High-performance running shoes with advanced cushioning technology for maximum comfort during long runs.',
    'SpeedMax',
    (SELECT id FROM categories WHERE slug = 'sports'),
    129.99,
    25,
    4.5,
    'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_7b1601f0-d308-43a8-af0a-009349798d6a.jpg',
    ARRAY['7', '8', '9', '10', '11', '12'],
    true,
    true,
    now() + interval '2 days'
  ),
  (
    'Urban Casual Sneaker',
    'Stylish casual sneakers perfect for everyday wear. Comfortable and versatile design.',
    'StreetStyle',
    (SELECT id FROM categories WHERE slug = 'sneakers'),
    89.99,
    15,
    4.3,
    'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_46acb01b-bd6c-4648-95fc-384e79e6e4df.jpg',
    ARRAY['6', '7', '8', '9', '10', '11'],
    true,
    false,
    NULL
  ),
  (
    'Kids Rainbow Sport',
    'Colorful and fun sports shoes designed for active kids. Durable and comfortable.',
    'JuniorFit',
    (SELECT id FROM categories WHERE slug = 'kids'),
    59.99,
    20,
    4.7,
    'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_0d974f21-f6a0-4b17-8375-80755e9d2804.jpg',
    ARRAY['1', '2', '3', '4', '5', '6'],
    true,
    true,
    now() + interval '2 days'
  ),
  (
    'Elegant Fashion Boot',
    'Premium leather boots with elegant design. Perfect for formal and casual occasions.',
    'LuxeWalk',
    (SELECT id FROM categories WHERE slug = 'women'),
    149.99,
    30,
    4.6,
    'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_37aa4dec-c4ff-4a11-b5bd-f552154dcd31.jpg',
    ARRAY['5', '6', '7', '8', '9', '10'],
    true,
    false,
    NULL
  ),
  (
    'Classic Leather Oxford',
    'Timeless leather formal shoes for the modern gentleman. Handcrafted quality.',
    'GentleMan',
    (SELECT id FROM categories WHERE slug = 'men'),
    179.99,
    10,
    4.4,
    'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_78ade549-fe68-45fa-b3bb-4d78fdb64f2e.jpg',
    ARRAY['7', '8', '9', '10', '11', '12'],
    true,
    false,
    NULL
  ),
  (
    'Basketball High-Top Elite',
    'Professional basketball shoes with superior ankle support and grip.',
    'CourtKing',
    (SELECT id FROM categories WHERE slug = 'sports'),
    159.99,
    20,
    4.8,
    'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_c75c8f91-a615-4a84-8d3d-a302e5fc5964.jpg',
    ARRAY['8', '9', '10', '11', '12', '13'],
    true,
    true,
    now() + interval '2 days'
  ),
  (
    'Professional Leather Boot',
    'Premium black leather boots for professional settings. Durable and stylish.',
    'ExecutiveWear',
    (SELECT id FROM categories WHERE slug = 'men'),
    199.99,
    15,
    4.5,
    'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_74ed5138-fb92-4238-877f-2f6d6009627b.jpg',
    ARRAY['7', '8', '9', '10', '11', '12'],
    true,
    false,
    NULL
  ),
  (
    'Vibrant Running Shoes',
    'Eye-catching colorful running shoes with excellent performance features.',
    'ColorRun',
    (SELECT id FROM categories WHERE slug = 'sports'),
    119.99,
    25,
    4.6,
    'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_8582b9aa-c502-4d21-9fb0-3b9a79cd8c5d.jpg',
    ARRAY['6', '7', '8', '9', '10', '11'],
    true,
    false,
    NULL
  ),
  (
    'Classic Canvas Sneaker',
    'Timeless white canvas sneakers. A wardrobe essential for any casual outfit.',
    'ClassicFit',
    (SELECT id FROM categories WHERE slug = 'sneakers'),
    69.99,
    10,
    4.2,
    'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_d52424f6-aa6b-4391-8684-81ee2404a7fe.jpg',
    ARRAY['6', '7', '8', '9', '10', '11'],
    true,
    false,
    NULL
  ),
  (
    'Comfort Slip-On Loafer',
    'Easy slip-on loafers with premium comfort. Perfect for relaxed occasions.',
    'EasyWalk',
    (SELECT id FROM categories WHERE slug = 'men'),
    99.99,
    20,
    4.3,
    'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_34054a74-9c41-43dc-9890-15ef38a2804b.jpg',
    ARRAY['7', '8', '9', '10', '11', '12'],
    true,
    false,
    NULL
  );

-- Insert sample coupons
INSERT INTO coupons (code, discount_percentage, expires_at, is_active) VALUES
  ('WELCOME10', 10, now() + interval '30 days', true),
  ('FLASH25', 25, now() + interval '7 days', true),
  ('SAVE15', 15, now() + interval '14 days', true);